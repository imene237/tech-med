import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { FolderIcon, ArrowRightIcon } from 'lucide-react';
import ArticleCard from '@/components/ArticleCard';
import type { Category, Article } from '@shared/schema';

const Categories = () => {
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  
  // Fetch all categories
  const { data: categories, isLoading: categoriesLoading } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });
  
  // Fetch all published articles
  const { data: articles, isLoading: articlesLoading } = useQuery<Article[]>({
    queryKey: ['/api/articles', { published: true }],
  });
  
  // Filter articles by category
  const getArticlesByCategory = (categoryId: number) => {
    if (!articles) return [];
    return articles.filter(article => article.categoryId === categoryId);
  };
  
  const handleCategoryChange = (categoryId: string) => {
    setActiveCategory(categoryId);
  };
  
  return (
    <div className="bg-gray-900 min-h-screen py-12 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-purple-400 to-indigo-300 bg-clip-text text-transparent">Categories</h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Browse electronics topics in medical education to find exactly what you're looking for
          </p>
        </div>
        
        {categoriesLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {Array(6).fill(0).map((_, i) => (
              <Skeleton key={i} className="h-40 rounded-lg" />
            ))}
          </div>
        ) : categories && categories.length > 0 ? (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
              {categories.map(category => (
                <Card 
                  key={category.id}
                  className="hover:shadow-md transition-shadow cursor-pointer bg-gray-800 border-gray-700"
                  onClick={() => handleCategoryChange(category.id.toString())}
                >
                  <CardHeader className="pb-2">
                    <CardTitle className="flex items-center text-white">
                      <FolderIcon className="h-5 w-5 mr-2 text-purple-400" />
                      {category.name}
                    </CardTitle>
                    <CardDescription className="text-gray-400">
                      Browse articles in this category
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex justify-between items-center">
                      <Badge variant="outline" className="bg-purple-900 bg-opacity-30 text-purple-300 border-purple-700">
                        {articlesLoading 
                          ? '...' 
                          : `${getArticlesByCategory(category.id).length} articles`}
                      </Badge>
                      <ArrowRightIcon className="h-4 w-4 text-purple-400" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            
            <div className="mt-10">
              <Tabs
                defaultValue={activeCategory || categories[0]?.id.toString()}
                value={activeCategory || categories[0]?.id.toString()}
                onValueChange={handleCategoryChange}
                className="w-full"
              >
                <div className="border-b border-gray-700 mb-8">
                  <TabsList className="inline-flex h-10 items-center justify-center rounded-none p-0 w-auto bg-transparent">
                    {categories.map(category => (
                      <TabsTrigger 
                        key={category.id}
                        value={category.id.toString()}
                        className="rounded-none border-b-2 border-transparent text-gray-400 hover:text-gray-200 data-[state=active]:border-purple-500 data-[state=active]:text-purple-300 px-4"
                      >
                        {category.name}
                      </TabsTrigger>
                    ))}
                  </TabsList>
                </div>
                
                {categories.map(category => (
                  <TabsContent key={category.id} value={category.id.toString()}>
                    <h2 className="text-2xl font-bold text-white mb-6">
                      {category.name} <span className="bg-gradient-to-r from-purple-400 to-indigo-300 bg-clip-text text-transparent">Articles</span>
                    </h2>
                    
                    {articlesLoading ? (
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                        {Array(3).fill(0).map((_, i) => (
                          <Skeleton key={i} className="h-96 rounded-lg" />
                        ))}
                      </div>
                    ) : getArticlesByCategory(category.id).length > 0 ? (
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                        {getArticlesByCategory(category.id).map(article => (
                          <ArticleCard key={article.id} article={article} />
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-12 bg-gray-800 rounded-lg shadow-md border border-gray-700">
                        <h3 className="text-xl font-semibold mb-2 text-white">No articles in this category yet</h3>
                        <p className="text-gray-400 mb-6">Be the first to write an article in this category.</p>
                        <Link href="/create">
                          <Button className="bg-purple-600 hover:bg-purple-700 cursor-pointer">Create Article</Button>
                        </Link>
                      </div>
                    )}
                  </TabsContent>
                ))}
              </Tabs>
            </div>
          </>
        ) : (
          <div className="text-center py-12 bg-gray-800 rounded-lg shadow-md border border-gray-700">
            <h3 className="text-xl font-semibold mb-2 text-white">No categories found</h3>
            <p className="text-gray-400 mb-6">Categories will be displayed here once they are created.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Categories;

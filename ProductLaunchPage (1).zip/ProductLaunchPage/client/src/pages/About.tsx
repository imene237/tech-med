import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { 
  BookOpen, 
  PenTool, 
  Search, 
  Users, 
  Layout, 
  Code, 
  Shield,
  Zap
} from 'lucide-react';

const About = () => {
  return (
    <div className="bg-neutral-50 min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-primary mb-4">About Pencraft</h1>
          <p className="text-xl text-secondary max-w-3xl mx-auto">
            A modern blogging platform designed for creators who value beautiful content and seamless experiences.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-20">
          <div>
            <h2 className="text-3xl font-bold text-primary mb-6">Our Mission</h2>
            <p className="text-lg text-secondary mb-6">
              Pencraft was born from a simple idea: writing and publishing content should be a joyful experience. We believe that when creators have the right tools, they can focus on what matters most — crafting meaningful content that resonates with readers.
            </p>
            <p className="text-lg text-secondary mb-6">
              We're building a platform that combines powerful features with intuitive design, making it accessible for everyone from seasoned writers to those just starting their content journey.
            </p>
            <p className="text-lg text-secondary">
              Our goal is to empower writers with technology that enhances creativity rather than getting in the way. We want Pencraft to be the place where ideas transform into beautifully presented articles that engage and inspire readers.
            </p>
          </div>
          
          <div className="bg-white rounded-lg shadow-sm p-8 border border-neutral-100 h-fit">
            <h3 className="text-2xl font-bold text-primary mb-6">Why Choose Pencraft?</h3>
            
            <div className="space-y-6">
              <div className="flex items-start">
                <div className="mt-1 bg-accent bg-opacity-10 p-2 rounded mr-4">
                  <PenTool className="h-6 w-6 text-accent" />
                </div>
                <div>
                  <h4 className="text-lg font-semibold mb-1">Intuitive Writing Experience</h4>
                  <p className="text-secondary">Our editor is designed to be powerful yet simple, letting you focus on your words, not the interface.</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="mt-1 bg-accent bg-opacity-10 p-2 rounded mr-4">
                  <Layout className="h-6 w-6 text-accent" />
                </div>
                <div>
                  <h4 className="text-lg font-semibold mb-1">Beautiful Presentation</h4>
                  <p className="text-secondary">Your content deserves to look great. Pencraft ensures your articles shine with optimized typography and layout.</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="mt-1 bg-accent bg-opacity-10 p-2 rounded mr-4">
                  <Search className="h-6 w-6 text-accent" />
                </div>
                <div>
                  <h4 className="text-lg font-semibold mb-1">Discoverable Content</h4>
                  <p className="text-secondary">Categories, tags, and search functionality make it easy for readers to find exactly what they're looking for.</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="mt-1 bg-accent bg-opacity-10 p-2 rounded mr-4">
                  <Zap className="h-6 w-6 text-accent" />
                </div>
                <div>
                  <h4 className="text-lg font-semibold mb-1">Fast and Responsive</h4>
                  <p className="text-secondary">Pencraft is built for speed, ensuring your content loads quickly on any device.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mb-20">
          <h2 className="text-3xl font-bold text-primary mb-12 text-center">Our Core Values</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="border-t-4 border-t-accent">
              <CardContent className="pt-6">
                <BookOpen className="h-10 w-10 text-accent mb-4" />
                <h3 className="text-xl font-semibold mb-2">Quality Content</h3>
                <p className="text-secondary">
                  We believe in the power of well-crafted content to educate, inspire, and connect people.
                </p>
              </CardContent>
            </Card>
            
            <Card className="border-t-4 border-t-accent">
              <CardContent className="pt-6">
                <Users className="h-10 w-10 text-accent mb-4" />
                <h3 className="text-xl font-semibold mb-2">Community First</h3>
                <p className="text-secondary">
                  We're building Pencraft with and for our community of writers and readers.
                </p>
              </CardContent>
            </Card>
            
            <Card className="border-t-4 border-t-accent">
              <CardContent className="pt-6">
                <Code className="h-10 w-10 text-accent mb-4" />
                <h3 className="text-xl font-semibold mb-2">Continuous Innovation</h3>
                <p className="text-secondary">
                  We're constantly improving our platform based on feedback and emerging technologies.
                </p>
              </CardContent>
            </Card>
            
            <Card className="border-t-4 border-t-accent">
              <CardContent className="pt-6">
                <Shield className="h-10 w-10 text-accent mb-4" />
                <h3 className="text-xl font-semibold mb-2">Trust & Reliability</h3>
                <p className="text-secondary">
                  We're committed to building a platform you can depend on for your content needs.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
        
        <div className="bg-accent text-white rounded-lg overflow-hidden shadow-lg">
          <div className="grid grid-cols-1 md:grid-cols-2">
            <div className="p-12">
              <h2 className="text-3xl font-bold mb-6">Ready to Start Your Writing Journey?</h2>
              <p className="text-lg opacity-90 mb-8">
                Join Pencraft today and transform your writing experience with our powerful yet simple blogging platform.
              </p>
              <div className="space-x-4">
                <Link href="/create">
                  <Button variant="secondary" size="lg" className="cursor-pointer">Start Writing</Button>
                </Link>
                <Link href="/">
                  <Button variant="outline" className="text-white border-white hover:bg-accent-foreground cursor-pointer" size="lg">Join Waitlist</Button>
                </Link>
              </div>
            </div>
            
            <div className="bg-accent-foreground p-12 flex items-center justify-center">
              <div className="text-center">
                <div className="text-5xl font-bold mb-2">500+</div>
                <p className="text-lg opacity-90">Early Access Sign-ups</p>
                <div className="h-1 w-20 bg-white opacity-50 mx-auto my-6"></div>
                <div className="text-5xl font-bold mb-2">5</div>
                <p className="text-lg opacity-90">Content Categories</p>
                <div className="h-1 w-20 bg-white opacity-50 mx-auto my-6"></div>
                <div className="text-5xl font-bold mb-2">∞</div>
                <p className="text-lg opacity-90">Creative Possibilities</p>
              </div>
            </div>
          </div>
        </div>
        
        {/* Contact Section */}
        <div className="bg-white rounded-lg shadow-sm my-12 p-8 border border-neutral-100">
          <h2 className="text-3xl font-bold text-primary mb-6">Contact Us</h2>
          <form onSubmit={(e) => {
            e.preventDefault();
            // Handle form submission
            const { toast } = useToast();
            toast({
              title: "Message Sent",
              description: "Thank you for your message. We'll get back to you soon!",
            });
          }} className="space-y-6">
            <div>
              <label htmlFor="name" className="block text-sm font-medium mb-2">Name</label>
              <Input id="name" placeholder="Your name" required />
            </div>
            <div>
              <label htmlFor="email" className="block text-sm font-medium mb-2">Email</label>
              <Input id="email" type="email" placeholder="your@email.com" required />
            </div>
            <div>
              <label htmlFor="message" className="block text-sm font-medium mb-2">Message</label>
              <Textarea
                id="message"
                placeholder="How can we help you?"
                className="min-h-[150px]"
                required
              />
            </div>
            <Button type="submit" className="w-full">Send Message</Button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default About;

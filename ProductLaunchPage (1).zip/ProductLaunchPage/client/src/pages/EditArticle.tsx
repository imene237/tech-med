import { useQuery } from '@tanstack/react-query';
import { useRoute, Link } from 'wouter';
import { ChevronLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import ArticleEditor from '@/components/ArticleEditor';
import type { Article } from '@shared/schema';

const EditArticle = () => {
  const [match, params] = useRoute('/edit/:id');
  const id = params?.id ? parseInt(params.id, 10) : undefined;
  
  // Fetch article data
  const { data: article, isLoading, error } = useQuery<Article>({
    queryKey: [`/api/articles/${id}`],
    enabled: !!id,
  });
  
  if (isLoading) {
    return (
      <div className="bg-neutral-50 min-h-screen py-12">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <Skeleton className="h-8 w-64" />
            <Skeleton className="h-6 w-96 mt-2" />
          </div>
          
          <div className="bg-white rounded-lg p-6 shadow-sm border border-neutral-100">
            <div className="space-y-8">
              <Skeleton className="h-12 w-full" />
              <Skeleton className="h-10 w-1/3" />
              <Skeleton className="h-60 w-full" />
              <Skeleton className="h-20 w-full" />
              <Skeleton className="h-10 w-full" />
              <div className="flex justify-end">
                <Skeleton className="h-10 w-24" />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  if (error || !article) {
    return (
      <div className="bg-neutral-50 min-h-screen py-12">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-lg p-8 shadow-sm border border-neutral-100 text-center">
            <h1 className="text-3xl font-bold text-primary mb-4">Article Not Found</h1>
            <p className="text-secondary mb-6">Sorry, the article you're trying to edit doesn't exist or has been removed.</p>
            <Link href="/articles">
              <Button variant="outline" className="cursor-pointer">
                <ChevronLeft className="mr-2 h-4 w-4" />
                Back to Articles
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="bg-neutral-50 min-h-screen py-12">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8 flex items-center">
          <Link href={`/articles/${article.slug}`}>
            <Button variant="outline" size="sm" className="mr-4 cursor-pointer">
              <ChevronLeft className="h-4 w-4 mr-2" />
              Back to Article
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-primary">Edit Article</h1>
            <p className="text-secondary mt-2">Make changes to your article</p>
          </div>
        </div>
        
        <ArticleEditor article={article} isEditMode={true} />
      </div>
    </div>
  );
};

export default EditArticle;

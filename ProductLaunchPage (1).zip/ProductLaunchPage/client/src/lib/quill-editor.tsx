import { useRef, useEffect, useState } from 'react';
import ReactQuill, { Quill } from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import { apiRequest } from '@/lib/queryClient';
import { toast } from '@/hooks/use-toast';

interface QuillEditorProps {
  value: string;
  onChange: (content: string) => void;
}

// Define available formats
const formats = [
  'header', 'font', 'size',
  'bold', 'italic', 'underline', 'strike', 'blockquote',
  'list', 'bullet', 'indent',
  'link', 'image', 'video',
  'code-block'
];

// Custom image handler to upload images
function imageHandler(this: any) {
  const input = document.createElement('input');
  input.setAttribute('type', 'file');
  input.setAttribute('accept', 'image/*');
  input.click();

  input.onchange = async () => {
    if (!input.files || input.files.length === 0) return;
    
    const file = input.files[0];
    
    try {
      // Prepare form data
      const formData = new FormData();
      formData.append('image', file);
      
      // Show loading toast
      const loadingToast = toast({
        title: 'Uploading image...',
        description: 'Please wait while we upload your image.',
      });
      
      // Send request to the server
      const response = await apiRequest('POST', '/api/upload', undefined, {
        formData,
        isMultipart: true,
      });
      
      const data = await response.json();
      
      // Get quill instance
      const quill = this.quill;
      
      // Get current cursor position
      const range = quill.getSelection(true);
      
      // Insert image
      quill.insertEmbed(range.index, 'image', data.url);
      
      // Move cursor after image
      quill.setSelection(range.index + 1);
      
      // Dismiss loading toast and show success
      loadingToast.dismiss();
      toast({
        title: 'Image uploaded successfully',
        variant: 'success',
      });
    } catch (error) {
      console.error('Error uploading image:', error);
      toast({
        title: 'Image upload failed',
        description: 'There was an error uploading your image. Please try again.',
        variant: 'destructive',
      });
    }
  };
}

const QuillEditor = ({ value, onChange }: QuillEditorProps) => {
  const quillRef = useRef<ReactQuill>(null);
  
  const modules = {
    toolbar: {
      container: [
        [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
        ['bold', 'italic', 'underline', 'strike', 'blockquote'],
        [{'list': 'ordered'}, {'list': 'bullet'}, {'indent': '-1'}, {'indent': '+1'}],
        ['link', 'image', 'code-block'],
        ['clean']
      ],
      handlers: {
        image: imageHandler
      }
    }
  };

  return (
    <div className="bg-white border border-input rounded-md">
      <ReactQuill
        ref={quillRef}
        theme="snow"
        value={value}
        onChange={onChange}
        formats={formats}
        modules={modules}
        className="h-[400px] font-serif"
      />
    </div>
  );
};

export default QuillEditor;

import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

/**
 * Merge Tailwind CSS classes conditionally
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Format a date to a human-readable format
 */
export function formatDate(date: Date | string): string {
  const dateObj = date instanceof Date ? date : new Date(date);
  
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  }).format(dateObj);
}

/**
 * Generate a slug from a string
 */
export function generateSlug(text: string): string {
  return text
    .toString()
    .toLowerCase()
    .replace(/\s+/g, '-')        // Replace spaces with -
    .replace(/[^\w\-]+/g, '')    // Remove all non-word chars
    .replace(/\-\-+/g, '-')      // Replace multiple - with single -
    .replace(/^-+/, '')          // Trim - from start of text
    .replace(/-+$/, '');         // Trim - from end of text
}

/**
 * Create an excerpt from content
 */
export function createExcerpt(content: string, maxLength: number = 150): string {
  // Remove any HTML tags
  const textContent = content.replace(/<\/?[^>]+(>|$)/g, "");
  
  if (textContent.length <= maxLength) {
    return textContent;
  }
  
  // Find the last space before maxLength
  const lastSpace = textContent.substring(0, maxLength).lastIndexOf(' ');
  return textContent.substring(0, lastSpace) + '...';
}

/**
 * Safe navigation helper to prevent React navigation issues
 * This function uses a longer delay to ensure components unmount properly
 */
export function safeNavigate(navigateFn: (to: string) => void, path: string): void {
  // Create a small delay to allow React to finish its state updates
  // and prevent navigation conflicts
  document.body.style.pointerEvents = 'none'; // Prevent further clicks
  window.setTimeout(() => {
    document.body.style.pointerEvents = ''; // Reset pointer events
    navigateFn(path);
  }, 300);
}

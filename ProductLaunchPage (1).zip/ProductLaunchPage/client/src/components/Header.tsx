import { useState } from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Menu, X, Cpu, Zap } from "lucide-react";
import SearchBar from "./SearchBar";

const Header = () => {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const isActive = (path: string) => {
    return location === path;
  };

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  // Navigation link component to prevent nested <a> tags
  const NavLink = ({ href, className, children }: { href: string; className: string; children: React.ReactNode }) => (
    <Link href={href}>
      <span className={className} role="link" tabIndex={0}>
        {children}
      </span>
    </Link>
  );

  return (
    <header className="bg-gray-900 shadow-md sticky top-0 z-50 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex">
            <div className="flex-shrink-0 flex items-center">
              <Link href="/">
                <span className="flex items-center text-2xl font-bold text-accent hover:opacity-90 transition-opacity cursor-pointer">
                  <Cpu className="mr-2 h-6 w-6" />
                  <span className="bg-gradient-to-r from-purple-400 to-indigo-300 bg-clip-text text-transparent">
                    Electronics in Med School
                  </span>
                </span>
              </Link>
            </div>
            <nav className="hidden sm:ml-6 sm:flex sm:space-x-8" aria-label="Main Navigation">
              <NavLink 
                href="/"
                className={cn(
                  "border-transparent hover:border-purple-300 hover:text-white border-b-2 px-1 pt-1 inline-flex items-center text-sm font-medium text-gray-300 cursor-pointer",
                  isActive("/") && "border-accent text-white"
                )}
              >
                Home
              </NavLink>
              <NavLink 
                href="/articles"
                className={cn(
                  "border-transparent hover:border-purple-300 hover:text-white border-b-2 px-1 pt-1 inline-flex items-center text-sm font-medium text-gray-300 cursor-pointer",
                  isActive("/articles") && "border-accent text-white"
                )}
              >
                Articles
              </NavLink>
              <NavLink 
                href="/categories"
                className={cn(
                  "border-transparent hover:border-purple-300 hover:text-white border-b-2 px-1 pt-1 inline-flex items-center text-sm font-medium text-gray-300 cursor-pointer",
                  isActive("/categories") && "border-accent text-white"
                )}
              >
                Categories
              </NavLink>
              <NavLink 
                href="/about"
                className={cn(
                  "border-transparent hover:border-purple-300 hover:text-white border-b-2 px-1 pt-1 inline-flex items-center text-sm font-medium text-gray-300 cursor-pointer",
                  isActive("/about") && "border-accent text-white"
                )}
              >
                About
              </NavLink>
            </nav>
          </div>
          
          <div className="flex items-center">
            <div className="hidden md:ml-4 md:flex-shrink-0 md:flex md:items-center space-x-4">
              <SearchBar />
              <Link href="/create">
                <span className="inline-block">
                  <Button className="bg-purple-600 hover:bg-purple-700 text-white">
                    New Article
                  </Button>
                </span>
              </Link>
            </div>
            
            <div className="flex items-center sm:hidden ml-4">
              <button
                type="button"
                className="bg-gray-800 p-2 rounded-md text-gray-300 hover:text-white focus:outline-none focus:ring-1 focus:ring-accent"
                aria-expanded="false"
                onClick={toggleMobileMenu}
              >
                {mobileMenuOpen ? (
                  <X className="h-6 w-6" />
                ) : (
                  <Menu className="h-6 w-6" />
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="sm:hidden" id="mobile-menu">
          <div className="pt-2 pb-3 space-y-1 bg-gray-800 text-white">
            <NavLink 
              href="/"
              className={cn(
                "border-transparent border-l-4 text-gray-300 hover:bg-gray-700 hover:border-purple-300 hover:text-white block pl-3 pr-4 py-2 text-base font-medium cursor-pointer",
                isActive("/") && "bg-gray-700 border-l-4 border-purple-500 text-white"
              )}
            >
              Home
            </NavLink>
            <NavLink 
              href="/articles"
              className={cn(
                "border-transparent border-l-4 text-gray-300 hover:bg-gray-700 hover:border-purple-300 hover:text-white block pl-3 pr-4 py-2 text-base font-medium cursor-pointer",
                isActive("/articles") && "bg-gray-700 border-l-4 border-purple-500 text-white"
              )}
            >
              Articles
            </NavLink>
            <NavLink 
              href="/categories"
              className={cn(
                "border-transparent border-l-4 text-gray-300 hover:bg-gray-700 hover:border-purple-300 hover:text-white block pl-3 pr-4 py-2 text-base font-medium cursor-pointer",
                isActive("/categories") && "bg-gray-700 border-l-4 border-purple-500 text-white"
              )}
            >
              Categories
            </NavLink>
            <NavLink 
              href="/about"
              className={cn(
                "border-transparent border-l-4 text-gray-300 hover:bg-gray-700 hover:border-purple-300 hover:text-white block pl-3 pr-4 py-2 text-base font-medium cursor-pointer",
                isActive("/about") && "bg-gray-700 border-l-4 border-purple-500 text-white"
              )}
            >
              About
            </NavLink>
            <div className="pt-4 pb-2 border-t border-gray-700">
              <div className="relative mx-3">
                <SearchBar isMobile />
              </div>
              <div className="mt-3 mx-3">
                <Link href="/create">
                  <span className="block">
                    <Button className="w-full bg-purple-600 hover:bg-purple-700 text-white">
                      New Article
                    </Button>
                  </span>
                </Link>
              </div>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { apiRequest } from '@/lib/queryClient';
import { toast } from '@/hooks/use-toast';
import { UploadCloud, Check, AlertCircle } from 'lucide-react';

interface FileUploadProps {
  onUploadComplete: (url: string) => void;
  label?: string;
  description?: string;
}

export default function FileUpload({
  onUploadComplete,
  label = "Cover Image",
  description = "Upload a cover image for your article"
}: FileUploadProps) {
  const [isUploading, setIsUploading] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Reset errors
    setError(null);
    
    // Check file type
    if (!file.type.startsWith('image/')) {
      setError('Only image files are allowed');
      return;
    }
    
    // Check file size (limit to 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setError('File size must be less than 5MB');
      return;
    }

    // Create preview url
    const objectUrl = URL.createObjectURL(file);
    setPreviewUrl(objectUrl);

    // Prepare form data
    const formData = new FormData();
    formData.append('image', file);
    
    try {
      setIsUploading(true);
      
      // Send request to the server
      const response = await apiRequest('POST', '/api/upload', undefined, {
        formData,
        isMultipart: true,
      });
      
      const data = await response.json();
      
      // Call callback with the url
      onUploadComplete(data.url);
      
      toast({
        title: 'Image uploaded successfully',
        variant: 'success',
      });
    } catch (error) {
      console.error('Error uploading file:', error);
      setError('Failed to upload file. Please try again.');
      setPreviewUrl(null);
      
      toast({
        title: 'Upload failed',
        description: 'There was an error uploading your image.',
        variant: 'destructive',
      });
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="file-upload">{label}</Label>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
      
      {!previewUrl ? (
        <div className="border-2 border-dashed border-input rounded-lg p-8 text-center">
          <UploadCloud className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
          <div className="space-y-2">
            <p className="text-sm font-medium">Drag and drop your image here or click to browse</p>
            <p className="text-xs text-muted-foreground">JPG, PNG or GIF up to 5MB</p>
            <Button
              variant="secondary"
              disabled={isUploading}
              onClick={() => document.getElementById('file-upload')?.click()}
              className="mt-2"
            >
              {isUploading ? 'Uploading...' : 'Browse files'}
            </Button>
          </div>
          <Input
            id="file-upload"
            type="file"
            accept="image/*"
            className="hidden"
            disabled={isUploading}
            onChange={handleFileChange}
          />
        </div>
      ) : (
        <div className="relative rounded-lg overflow-hidden">
          <img
            src={previewUrl}
            alt="Preview"
            className="w-full h-48 object-cover"
          />
          <div className="absolute top-2 right-2">
            <div className="bg-background/80 rounded-full p-1">
              <Check className="h-5 w-5 text-success" />
            </div>
          </div>
          <Button
            variant="outline"
            size="sm"
            className="absolute bottom-2 right-2"
            onClick={() => {
              setPreviewUrl(null);
              const input = document.getElementById('file-upload') as HTMLInputElement;
              if (input) input.value = '';
            }}
          >
            Change image
          </Button>
        </div>
      )}
      
      {error && (
        <div className="text-destructive flex items-center gap-2 text-sm">
          <AlertCircle className="h-4 w-4" />
          {error}
        </div>
      )}
    </div>
  );
}

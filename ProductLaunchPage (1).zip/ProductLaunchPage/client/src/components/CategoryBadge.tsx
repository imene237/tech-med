import { useLocation } from 'wouter';
import { cn, safeNavigate } from '@/lib/utils';

interface CategoryBadgeProps {
  name: string;
  slug: string;
  className?: string;
}

const CategoryBadge = ({ name, slug, className }: CategoryBadgeProps) => {
  const [, navigate] = useLocation();
  
  const handleClick = (e: React.MouseEvent) => {
    e.preventDefault();
    safeNavigate(navigate, `/categories?slug=${slug}`);
  };
  
  return (
    <a 
      href={`/categories?slug=${slug}`}
      onClick={handleClick}
    >
      <span 
        className={cn(
          "text-xs font-medium px-2.5 py-1.5 bg-purple-900 bg-opacity-40 text-purple-300 rounded-full hover:bg-opacity-60 transition-colors border border-purple-700/50 cursor-pointer",
          className
        )}
      >
        {name}
      </span>
    </a>
  );
};

export default CategoryBadge;

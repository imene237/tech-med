import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { toast } from '@/hooks/use-toast';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { createExcerpt, generateSlug, safeNavigate } from '@/lib/utils';
import FileUpload from '@/components/ui/file-upload';
import QuillEditor from '@/lib/quill-editor';
import type { Category, Article } from '@shared/schema';

const articleFormSchema = z.object({
  title: z.string().min(3, { message: "Title must be at least 3 characters" }),
  excerpt: z.string().min(10, { message: "Excerpt must be at least 10 characters" }).max(300, { message: "Excerpt must be less than 300 characters" }),
  content: z.string().min(20, { message: "Content must be at least 20 characters" }),
  categoryId: z.string().min(1, { message: "Please select a category" }),
  coverImage: z.string().optional(),
  published: z.boolean().default(false),
});

type ArticleFormValues = z.infer<typeof articleFormSchema>;

interface ArticleEditorProps {
  article?: Article;
  isEditMode?: boolean;
}

const ArticleEditor = ({ article, isEditMode = false }: ArticleEditorProps) => {
  const [content, setContent] = useState('');
  const [coverImage, setCoverImage] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [, navigate] = useLocation();
  
  // Get categories for the dropdown
  const { data: categories, isLoading: isLoadingCategories } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });
  
  // Setup form with react-hook-form
  const form = useForm<ArticleFormValues>({
    resolver: zodResolver(articleFormSchema),
    defaultValues: {
      title: article?.title || "",
      excerpt: article?.excerpt || "",
      content: article?.content || "",
      categoryId: article?.categoryId.toString() || "",
      coverImage: article?.coverImage || "",
      published: article?.published || false,
    },
  });
  
  // Initialize form values when article data is available
  useEffect(() => {
    if (article && isEditMode) {
      form.reset({
        title: article.title,
        excerpt: article.excerpt,
        content: article.content,
        categoryId: article.categoryId.toString(),
        coverImage: article.coverImage || "",
        published: article.published,
      });
      
      setContent(article.content);
      setCoverImage(article.coverImage || "");
    }
  }, [article, form, isEditMode]);
  
  // Auto-fill content into the form when it changes
  const handleContentChange = (value: string) => {
    setContent(value);
    form.setValue('content', value, { shouldValidate: true });
    
    // Auto-generate excerpt from content if not manually edited or if it's empty
    const currentExcerpt = form.getValues('excerpt');
    if (!currentExcerpt || currentExcerpt === "") {
      const excerpt = createExcerpt(value);
      form.setValue('excerpt', excerpt, { shouldValidate: true });
    }
  };
  
  // Handle cover image upload
  const handleCoverImageUpload = (url: string) => {
    setCoverImage(url);
    form.setValue('coverImage', url, { shouldValidate: true });
  };
  
  // Handle article deletion
  const handleDeleteArticle = async () => {
    if (!article || !isEditMode) return;
    
    setIsDeleting(true);
    
    try {
      await apiRequest('DELETE', `/api/articles/${article.id}`);
      
      // Invalidate the articles query to refetch the list
      queryClient.invalidateQueries({ queryKey: ['/api/articles'] });
      
      toast({
        title: "Article deleted",
        description: "Your article has been successfully deleted.",
        variant: "default",
      });
      
      // Navigate back to articles page safely
      safeNavigate(navigate, '/articles');
    } catch (error) {
      console.error('Error deleting article:', error);
      toast({
        title: "Failed to delete article",
        description: "An error occurred while deleting your article. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsDeleting(false);
    }
  };
  
  // Handle form submission for create/update
  const onSubmit = async (data: ArticleFormValues) => {
    setIsSaving(true);
    
    try {
      if (isEditMode && article) {
        // Update existing article
        const response = await apiRequest('PUT', `/api/articles/${article.id}`, {
          title: data.title,
          content: data.content,
          excerpt: data.excerpt,
          categoryId: parseInt(data.categoryId),
          coverImage: data.coverImage || null,
          published: data.published,
        });
        
        const updatedArticle = await response.json();
        
        toast({
          title: "Article updated",
          description: data.published ? "Your article has been published." : "Your article has been saved as a draft.",
          variant: "default",
        });
        
        // Navigate to the article page safely
        safeNavigate(navigate, `/articles/${updatedArticle.slug}`);
      } else {
        // Create new article
        // Generate slug from title
        const slug = generateSlug(data.title);
        
        const response = await apiRequest('POST', '/api/articles', {
          title: data.title,
          slug,
          content: data.content,
          excerpt: data.excerpt,
          categoryId: parseInt(data.categoryId),
          coverImage: data.coverImage || null,
          authorId: 1,
          published: data.published,
        });
        
        const newArticle = await response.json();
        
        toast({
          title: "Article created",
          description: data.published ? "Your article has been published." : "Your article has been saved as a draft.",
          variant: "default",
        });
        
        // Navigate to the article page safely
        safeNavigate(navigate, `/articles/${newArticle.slug}`);
      }
      
      // Invalidate the articles query to refetch the list
      queryClient.invalidateQueries({ queryKey: ['/api/articles'] });
    } catch (error) {
      console.error('Error saving article:', error);
      toast({
        title: isEditMode ? "Failed to update article" : "Failed to create article",
        description: "An error occurred while saving your article. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };
  
  return (
    <Card>
      <CardContent className="p-6">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
            {/* Title field */}
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Title</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Enter article title" 
                      className="text-xl"
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Category field */}
            <FormField
              control={form.control}
              name="categoryId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                    value={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a category" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {isLoadingCategories ? (
                        <SelectItem value="_loading" disabled>Loading categories...</SelectItem>
                      ) : categories && categories.length > 0 ? (
                        categories.map(category => (
                          <SelectItem key={category.id} value={category.id.toString()}>
                            {category.name}
                          </SelectItem>
                        ))
                      ) : (
                        <SelectItem value="_none" disabled>No categories available</SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Cover Image field */}
            <div>
              <FileUpload
                onUploadComplete={handleCoverImageUpload}
                label="Cover Image"
                description="Upload a cover image for your article (optional)"
              />
            </div>
            
            {/* Content field */}
            <FormField
              control={form.control}
              name="content"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Content</FormLabel>
                  <FormControl>
                    <QuillEditor
                      value={content}
                      onChange={handleContentChange}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Excerpt field */}
            <FormField
              control={form.control}
              name="excerpt"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Excerpt</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Brief summary of your article"
                      className="resize-none"
                      {...field}
                    />
                  </FormControl>
                  <p className="text-sm text-muted-foreground">
                    This will be displayed in article previews. If left empty, it will be generated automatically.
                  </p>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Published field */}
            <FormField
              control={form.control}
              name="published"
              render={({ field }) => (
                <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                  <div className="space-y-0.5">
                    <FormLabel className="text-base">Publish Article</FormLabel>
                    <p className="text-sm text-muted-foreground">
                      {field.value ? 
                        "Your article will be publicly visible after saving." : 
                        "Save as draft to publish later."}
                    </p>
                  </div>
                  <FormControl>
                    <Switch
                      checked={field.value}
                      onCheckedChange={field.onChange}
                    />
                  </FormControl>
                </FormItem>
              )}
            />
            
            <div className="flex justify-between space-x-4">
              {isEditMode && article && (
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button
                      type="button"
                      variant="destructive"
                      disabled={isDeleting || isSaving}
                    >
                      {isDeleting ? 'Deleting...' : 'Delete Article'}
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                      <AlertDialogDescription>
                        This action cannot be undone. This will permanently delete your article.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={handleDeleteArticle}>
                        Delete
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              )}
              
              <div className="flex justify-end ml-auto space-x-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    // Navigate safely
                    safeNavigate(navigate, '/articles');
                  }}
                  disabled={isSaving}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  className="bg-accent hover:bg-blue-600"
                  disabled={isSaving}
                >
                  {isSaving 
                    ? 'Saving...' 
                    : isEditMode 
                      ? (form.getValues('published') ? 'Update & Publish' : 'Update Draft')
                      : (form.getValues('published') ? 'Publish Article' : 'Save Draft')
                  }
                </Button>
              </div>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
};

export default ArticleEditor;

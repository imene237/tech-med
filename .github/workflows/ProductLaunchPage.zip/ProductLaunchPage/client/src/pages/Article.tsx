import { useQuery } from '@tanstack/react-query';
import { useRoute, useLocation } from 'wouter';
import { safeNavigate, formatDate, cn } from '@/lib/utils';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { PenIcon, ChevronLeft } from 'lucide-react';
import CategoryBadge from '@/components/CategoryBadge';
import type { Article as ArticleType, Category, User } from '@shared/schema';

const Article = () => {
  const [match, params] = useRoute('/articles/:slug');
  const [, navigate] = useLocation();
  const slug = params?.slug;
  
  // Fetch article data
  const { data: article, isLoading, error } = useQuery<ArticleType>({
    queryKey: [`/api/articles/slug/${slug}`],
    enabled: !!slug,
  });
  
  // Fetch category data if article is loaded
  const { data: category } = useQuery<Category>({
    queryKey: [`/api/categories/${article?.categoryId}`],
    enabled: !!article,
  });
  
  // Fetch author data if article is loaded
  const { data: author } = useQuery<User>({
    queryKey: [`/api/users/${article?.authorId}`],
    enabled: !!article,
  });
  
  if (isLoading) {
    return (
      <div className="bg-gray-900 min-h-screen py-12">
        <div className="max-w-4xl mx-auto px-4">
          <div className="space-y-6">
            <Skeleton className="h-12 w-3/4 bg-gray-800" />
            <div className="flex gap-4">
              <Skeleton className="h-6 w-24 bg-gray-800" />
              <Skeleton className="h-6 w-32 bg-gray-800" />
            </div>
            <Skeleton className="h-80 w-full bg-gray-800" />
            <div className="space-y-4">
              <Skeleton className="h-6 w-full bg-gray-800" />
              <Skeleton className="h-6 w-full bg-gray-800" />
              <Skeleton className="h-6 w-3/4 bg-gray-800" />
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  if (error || !article) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-12 text-center bg-gray-900 min-h-screen flex flex-col items-center justify-center">
        <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-indigo-300 bg-clip-text text-transparent mb-4">Article Not Found</h1>
        <p className="text-gray-400 mb-6">Sorry, the article you're looking for doesn't exist or has been removed.</p>
        <Button 
          variant="outline" 
          className="bg-gray-800 border-gray-700 text-gray-200 hover:bg-gray-700 hover:text-white cursor-pointer"
          onClick={() => safeNavigate(navigate, '/articles')}
        >
          <ChevronLeft className="mr-2 h-4 w-4" />
          Back to Articles
        </Button>
      </div>
    );
  }
  
  return (
    <div className="bg-gray-900 min-h-screen">
      {/* Article header */}
      <header className={cn(
        "bg-gray-800 border-b border-gray-700 py-12",
        article.coverImage ? "pb-0" : ""
      )}>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-6">
            <Button 
              variant="outline" 
              size="sm" 
              className="bg-gray-700 border-gray-600 text-gray-200 hover:bg-gray-600 hover:text-white cursor-pointer"
              onClick={() => safeNavigate(navigate, '/articles')}
            >
              <ChevronLeft className="mr-2 h-4 w-4" />
              Back to Articles
            </Button>
          </div>
          
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-white mb-4 bg-gradient-to-r from-purple-400 to-indigo-300 bg-clip-text text-transparent">{article.title}</h1>
            
            <div className="flex flex-wrap items-center gap-3 text-sm text-gray-400">
              {category && (
                <CategoryBadge name={category.name} slug={category.slug} />
              )}
              
              <span>{formatDate(article.createdAt)}</span>
              
              {author && (
                <div className="flex items-center">
                  <span className="mx-2 text-gray-500">•</span>
                  <div className="flex items-center">
                    <div className="w-6 h-6 bg-purple-600 rounded-full flex items-center justify-center text-white text-xs mr-2">
                      {author.username.charAt(0).toUpperCase()}
                    </div>
                    <span className="text-gray-300">{author.username}</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
        
        {article.coverImage && (
          <div className="w-full h-80 overflow-hidden">
            <img 
              src={article.coverImage} 
              alt={article.title} 
              className="w-full h-full object-cover"
            />
          </div>
        )}
      </header>
      
      {/* Article content */}
      <article className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div 
          className="article-content prose prose-lg prose-invert prose-headings:text-purple-300 prose-a:text-purple-300 max-w-none text-gray-200"
          dangerouslySetInnerHTML={{ __html: article.content }}
        />
        
        <div className="mt-12 pt-8 border-t border-gray-700">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              {author && (
                <>
                  <div className="w-10 h-10 bg-purple-600 rounded-full flex items-center justify-center text-white text-lg mr-3">
                    {author.username.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <p className="font-medium text-white">{author.username}</p>
                    <p className="text-sm text-gray-400">Author</p>
                  </div>
                </>
              )}
            </div>
            
            <Button 
              variant="outline" 
              className="bg-gray-700 border-gray-600 text-gray-200 hover:bg-gray-600 hover:text-white cursor-pointer"
              onClick={() => safeNavigate(navigate, `/edit/${article.id}`)}
            >
              <PenIcon className="mr-2 h-4 w-4" />
              Edit Article
            </Button>
          </div>
        </div>
      </article>
    </div>
  );
};

export default Article;
import { useState } from 'react';
import { useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { toast } from '@/hooks/use-toast';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { createExcerpt, generateSlug, safeNavigate } from '@/lib/utils';
import FileUpload from '@/components/ui/file-upload';
import QuillEditor from '@/lib/quill-editor';
import type { Category } from '@shared/schema';

const articleFormSchema = z.object({
  title: z.string().min(3, { message: "Title must be at least 3 characters" }),
  excerpt: z.string().min(10, { message: "Excerpt must be at least 10 characters" }).max(300, { message: "Excerpt must be less than 300 characters" }),
  content: z.string().min(20, { message: "Content must be at least 20 characters" }),
  categoryId: z.string().min(1, { message: "Please select a category" }),
  coverImage: z.string().optional(),
  published: z.boolean().default(false),
});

type ArticleFormValues = z.infer<typeof articleFormSchema>;

const CreateArticle = () => {
  const [content, setContent] = useState('');
  const [coverImage, setCoverImage] = useState('');
  const [, navigate] = useLocation();

  // Get categories for the dropdown
  const { data: categories, isLoading: isLoadingCategories } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  // Setup form with react-hook-form
  const form = useForm<ArticleFormValues>({
    resolver: zodResolver(articleFormSchema),
    defaultValues: {
      title: "",
      excerpt: "",
      content: "",
      categoryId: "",
      coverImage: "",
      published: false,
    },
  });

  // Watch the title to generate an excerpt automatically
  const watchedTitle = form.watch('title');

  // Auto-fill content into the form when it changes
  const handleContentChange = (value: string) => {
    setContent(value);
    form.setValue('content', value, { shouldValidate: true });

    // Auto-generate excerpt from content if not manually edited
    if (!form.getValues('excerpt') || form.getValues('excerpt') === "") {
      const excerpt = createExcerpt(value);
      form.setValue('excerpt', excerpt, { shouldValidate: true });
    }
  };

  // Handle cover image upload
  const handleCoverImageUpload = (url: string) => {
    setCoverImage(url);
    form.setValue('coverImage', url, { shouldValidate: true });
  };

  // Handle form submission
  const onSubmit = async (data: ArticleFormValues) => {
    try {
      // Generate slug from title
      const slug = generateSlug(data.title);

      // Create the article
      const response = await apiRequest('POST', '/api/articles', {
        title: data.title,
        slug,
        content: data.content,
        excerpt: data.excerpt,
        categoryId: parseInt(data.categoryId),
        coverImage: data.coverImage || null,
        authorId: 1,
        published: data.published,
      });

      const article = await response.json();

      // Invalidate the articles query to refetch the list
      queryClient.invalidateQueries({ queryKey: ['/api/articles'] });

      toast({
        title: "Article created",
        description: data.published ? "Your article has been published." : "Your article has been saved as a draft.",
        variant: "default",
      });

      // Navigate to the article page safely
      safeNavigate(navigate, `/articles/${article.slug}`);
    } catch (error) {
      console.error('Error creating article:', error);
      toast({
        title: "Failed to create article",
        description: "An error occurred while creating your article. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="bg-neutral-50 min-h-screen py-12">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-primary">Create New Article</h1>
          <p className="text-secondary mt-2">Share your knowledge with the world</p>
        </div>

        <Card>
          <CardContent className="p-6">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                {/* Title field */}
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Title</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Enter article title" 
                          className="text-xl"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Category field */}
                <FormField
                  control={form.control}
                  name="categoryId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Category</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a category" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {isLoadingCategories ? (
                            <SelectItem value="loading" disabled>Loading categories...</SelectItem>
                          ) : categories && categories.length > 0 ? (
                            categories.map(category => (
                              <SelectItem key={category.id} value={category.id.toString()}>
                                {category.name}
                              </SelectItem>
                            ))
                          ) : (
                            <SelectItem value="none" disabled>No categories available</SelectItem>
                          )}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Cover Image field */}
                <div>
                  <FileUpload
                    onUploadComplete={handleCoverImageUpload}
                    label="Cover Image"
                    description="Upload a cover image for your article (optional)"
                  />
                </div>

                {/* Content field */}
                <FormField
                  control={form.control}
                  name="content"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Content</FormLabel>
                      <FormControl>
                        <QuillEditor
                          value={content}
                          onChange={handleContentChange}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Excerpt field */}
                <FormField
                  control={form.control}
                  name="excerpt"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Excerpt</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Brief summary of your article"
                          className="resize-none"
                          {...field}
                        />
                      </FormControl>
                      <p className="text-sm text-muted-foreground">
                        This will be displayed in article previews. If left empty, it will be generated automatically.
                      </p>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Published field */}
                <FormField
                  control={form.control}
                  name="published"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                      <div className="space-y-0.5">
                        <FormLabel className="text-base">Publish Article</FormLabel>
                        <p className="text-sm text-muted-foreground">
                          {field.value ? 
                            "Your article will be publicly visible after saving." : 
                            "Save as draft to publish later."}
                        </p>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />

                <div className="flex justify-end space-x-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => safeNavigate(navigate, '/articles')}
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit"
                    className="bg-accent hover:bg-blue-600"
                  >
                    {form.getValues('published') ? 'Publish Article' : 'Save Draft'}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default CreateArticle;
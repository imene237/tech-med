import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Search } from 'lucide-react';
import ArticleCard from '@/components/ArticleCard';
import type { Article, Category } from '@shared/schema';

const Articles = () => {
  const [location] = useLocation();
  const [searchParams, setSearchParams] = useState(new URLSearchParams(window.location.search));
  const [searchTerm, setSearchTerm] = useState(searchParams.get('search') || '');
  const [selectedCategory, setSelectedCategory] = useState(searchParams.get('category') || '_all');
  
  // Get articles
  const { data: articles, isLoading: isLoadingArticles } = useQuery<Article[]>({
    queryKey: ['/api/articles', { authorId: 1 }],
  });
  
  // Get categories
  const { data: categories, isLoading: isLoadingCategories } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });
  
  // Filter articles based on search and category
  const filteredArticles = articles?.filter(article => {
    const matchesSearch = !searchTerm || 
      article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      article.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = selectedCategory === '_all' || 
      article.categoryId === parseInt(selectedCategory);

    const authorId = 1; // Current logged in user ID
    const isAuthor = article.authorId === authorId;
    
    return matchesSearch && matchesCategory && isAuthor;
  }) || [];
  
  // Update URL when search or category changes
  useEffect(() => {
    const params = new URLSearchParams();
    if (searchTerm) params.set('search', searchTerm);
    if (selectedCategory !== '_all') params.set('category', selectedCategory);
    
    const newUrl = `${window.location.pathname}${params.toString() ? `?${params.toString()}` : ''}`;
    window.history.replaceState({}, '', newUrl);
  }, [searchTerm, selectedCategory]);
  
  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
  };
  
  const handleCategoryChange = (value: string) => {
    setSelectedCategory(value);
  };
  
  const clearFilters = () => {
    setSearchTerm('');
    setSelectedCategory('_all');
  };
  
  return (
    <div className="bg-gray-900 min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-indigo-300 bg-clip-text text-transparent mb-4">Articles</h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Explore our collection of articles on electronic innovations in medical education.
          </p>
        </div>
        
        <div className="mb-8 p-6 bg-gray-800 rounded-lg shadow-md border border-gray-700">
          <div className="flex flex-col md:flex-row gap-4 items-end">
            <div className="flex-grow">
              <form onSubmit={handleSearchSubmit}>
                <div className="relative">
                  <Input
                    type="text"
                    placeholder="Search medical electronics articles..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 bg-gray-700 border-gray-600 text-gray-200 placeholder:text-gray-400 focus:border-purple-500 focus-visible:ring-purple-500/30"
                  />
                  <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                    <Search className="h-4 w-4 text-gray-400" />
                  </div>
                </div>
              </form>
            </div>
            
            <div className="w-full md:w-64">
              {isLoadingCategories ? (
                <Skeleton className="h-10 w-full bg-gray-700" />
              ) : (
                <Select value={selectedCategory} onValueChange={handleCategoryChange}>
                  <SelectTrigger className="bg-gray-700 border-gray-600 text-gray-200 focus:border-purple-500 focus-visible:ring-purple-500/30">
                    <SelectValue placeholder="Filter by category" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-700 text-gray-200">
                    <SelectItem value="_all" className="hover:bg-gray-700 focus:bg-gray-700">All Categories</SelectItem>
                    {categories?.map(category => (
                      <SelectItem 
                        key={category.id} 
                        value={category.id.toString()}
                        className="hover:bg-gray-700 focus:bg-gray-700"
                      >
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>
            
            {(searchTerm || selectedCategory !== '_all') && (
              <Button 
                variant="outline" 
                onClick={clearFilters}
                className="bg-gray-700 border-gray-600 text-gray-200 hover:bg-gray-600 hover:text-white"
              >
                Clear Filters
              </Button>
            )}
          </div>
        </div>
        
        {isLoadingArticles ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {Array(6).fill(0).map((_, i) => (
              <div key={i} className="bg-gray-800 rounded-lg shadow-md border border-gray-700 flex flex-col">
                <div className="h-48 bg-gray-700 animate-pulse" />
                <div className="p-6 space-y-3">
                  <div className="h-6 bg-gray-700 rounded animate-pulse w-1/3" />
                  <div className="h-8 bg-gray-700 rounded animate-pulse" />
                  <div className="h-20 bg-gray-700 rounded animate-pulse" />
                  <div className="h-8 bg-gray-700 rounded animate-pulse w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : filteredArticles.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredArticles.map(article => (
              <ArticleCard key={article.id} article={article} />
            ))}
          </div>
        ) : (
          <div className="text-center py-16 bg-gray-800 rounded-lg shadow-md border border-gray-700">
            <h3 className="text-xl font-semibold mb-2 text-white">No articles found</h3>
            <p className="text-gray-400 mb-6">
              {searchTerm || selectedCategory !== '_all' ? 
                "Try adjusting your filters to find what you're looking for." : 
                "Check back later for new content."}
            </p>
            {(searchTerm || selectedCategory !== '_all') && (
              <Button 
                variant="outline" 
                onClick={clearFilters}
                className="bg-gray-700 border-gray-600 text-gray-200 hover:bg-gray-600 hover:text-white"
              >
                Clear Filters
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default Articles;
import { useState } from 'react';
import { Link } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from 'zod';
import { CheckIcon, PencilIcon, UploadCloud, Image, Search, BookOpen, TagsIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import ArticleCard from '@/components/ArticleCard';
import type { Article } from '@shared/schema';

const waitlistFormSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters" }),
  email: z.string().email({ message: "Please enter a valid email address" }),
  useCase: z.string().min(1, { message: "Please select an option" }),
});

type WaitlistFormValues = z.infer<typeof waitlistFormSchema>;

const Home = () => {
  const [submitting, setSubmitting] = useState(false);
  const [submissionSuccess, setSubmissionSuccess] = useState(false);
  
  // Fetch featured articles (published only)
  const { data: articles, isLoading } = useQuery<Article[]>({
    queryKey: ['/api/articles', { published: true }],
  });
  
  // Get most recent 3 articles
  const featuredArticles = articles?.slice(0, 3) || [];
  
  // Setup form with react-hook-form
  const form = useForm<WaitlistFormValues>({
    resolver: zodResolver(waitlistFormSchema),
    defaultValues: {
      name: "",
      email: "",
      useCase: "",
    },
  });
  
  const onSubmit = async (data: WaitlistFormValues) => {
    setSubmitting(true);
    
    try {
      await apiRequest('POST', '/api/waitlist', {
        name: data.name,
        email: data.email,
        useCase: data.useCase,
      });
      
      toast({
        title: "Success!",
        description: "You've been added to our waitlist. We'll notify you when we launch.",
        variant: "default",
      });
      
      setSubmissionSuccess(true);
    } catch (error) {
      console.error('Error submitting waitlist form:', error);
      toast({
        title: "Something went wrong",
        description: "Failed to add you to the waitlist. Please try again.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };
  
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="bg-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold tracking-tight sm:text-5xl mb-6 bg-gradient-to-r from-purple-500 to-indigo-400 bg-clip-text text-transparent">
                Electronics in Medical Education
              </h2>
              <p className="text-xl text-gray-700 mb-8">
                Explore the intersection of electronic technology and medical science - from surgical devices to diagnostic equipment.
              </p>
              <Card className="bg-neutral-50 border border-neutral-100">
                <CardContent className="pt-6">
                  <h3 className="text-xl font-semibold mb-4">Join the Waitlist</h3>
                  <p className="text-secondary mb-6">Get early access to our platform and special launch offers.</p>
                  
                  {!submissionSuccess ? (
                    <Form {...form}>
                      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                        <FormField
                          control={form.control}
                          name="name"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Your Name</FormLabel>
                              <FormControl>
                                <Input placeholder="John Doe" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Email Address</FormLabel>
                              <FormControl>
                                <Input placeholder="john@example.com" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="useCase"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>What is your interest in medical electronics?</FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select an option" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="student">Medical Student</SelectItem>
                                  <SelectItem value="professional">Healthcare Professional</SelectItem>
                                  <SelectItem value="engineer">Electronics Engineer</SelectItem>
                                  <SelectItem value="researcher">Medical Researcher</SelectItem>
                                  <SelectItem value="other">Other</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <Button 
                          type="submit" 
                          className="w-full bg-purple-600 hover:bg-purple-700 text-white"
                          disabled={submitting}
                        >
                          {submitting ? 'Processing...' : 'Join the Waitlist'}
                        </Button>
                      </form>
                    </Form>
                  ) : (
                    <div className="text-center p-4">
                      <div className="w-16 h-16 bg-success rounded-full flex items-center justify-center mx-auto mb-4">
                        <CheckIcon className="text-white h-8 w-8" />
                      </div>
                      <h3 className="text-xl font-semibold mb-2">You're on the List!</h3>
                      <p className="text-secondary">Thank you for joining our waitlist. We'll notify you when we launch.</p>
                      <p className="mt-4 text-sm text-accent">We sent a confirmation to {form.getValues().email}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
            
            <div className="relative hidden md:block">
              <div className="bg-accent rounded-xl shadow-lg transform rotate-2 p-2">
                <img 
                  src="https://images.unsplash.com/photo-1531297484001-80022131f5a1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1740&q=80" 
                  alt="Pencraft editor interface" 
                  className="rounded-lg shadow-inner"
                />
              </div>
              <div className="absolute -bottom-6 -left-6 bg-white rounded-lg shadow-lg p-4 transform -rotate-2 w-64">
                <div className="flex items-center mb-2">
                  <div className="w-8 h-8 bg-success rounded-full flex items-center justify-center text-white">
                    <CheckIcon className="h-4 w-4" />
                  </div>
                  <span className="ml-2 font-medium">Article Published!</span>
                </div>
                <p className="text-xs text-secondary">Your article "Electronics are everywhere in your daily life!" is now live.</p>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Features Section */}
      <section className="bg-neutral-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-primary sm:text-4xl">Everything You Need to Create and Manage Content</h2>
            <p className="mt-4 text-xl text-secondary max-w-3xl mx-auto">Pencraft brings together powerful tools in an intuitive interface.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white rounded-lg shadow-sm p-6 border border-neutral-100">
              <div className="w-12 h-12 bg-accent bg-opacity-10 rounded-lg flex items-center justify-center mb-4">
                <PencilIcon className="text-accent h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Rich Text Editor</h3>
              <p className="text-secondary">Craft beautiful articles with our intuitive editor. Format text, add images, embed content, and more.</p>
            </div>
            
            <div className="bg-white rounded-lg shadow-sm p-6 border border-neutral-100">
              <div className="w-12 h-12 bg-accent bg-opacity-10 rounded-lg flex items-center justify-center mb-4">
                <UploadCloud className="text-accent h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Image Uploads</h3>
              <p className="text-secondary">Easily upload, crop and organize images within your articles. Automatic optimization for fast loading.</p>
            </div>
            
            <div className="bg-white rounded-lg shadow-sm p-6 border border-neutral-100">
              <div className="w-12 h-12 bg-accent bg-opacity-10 rounded-lg flex items-center justify-center mb-4">
                <TagsIcon className="text-accent h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Categories & Tags</h3>
              <p className="text-secondary">Organize your content with a flexible categorization system. Help readers discover related articles.</p>
            </div>
            
            <div className="bg-white rounded-lg shadow-sm p-6 border border-neutral-100">
              <div className="w-12 h-12 bg-accent bg-opacity-10 rounded-lg flex items-center justify-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-accent h-6 w-6">
                  <rect x="5" y="2" width="14" height="20" rx="2" ry="2" />
                  <line x1="12" y1="18" x2="12.01" y2="18" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">Responsive Design</h3>
              <p className="text-secondary">Your blog looks great on every device. Write once, publish everywhere with automatic adaptation.</p>
            </div>
            
            <div className="bg-white rounded-lg shadow-sm p-6 border border-neutral-100">
              <div className="w-12 h-12 bg-accent bg-opacity-10 rounded-lg flex items-center justify-center mb-4">
                <Search className="text-accent h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Search Functionality</h3>
              <p className="text-secondary">Help readers find exactly what they're looking for with powerful search capabilities.</p>
            </div>
            
            <div className="bg-white rounded-lg shadow-sm p-6 border border-neutral-100">
              <div className="w-12 h-12 bg-accent bg-opacity-10 rounded-lg flex items-center justify-center mb-4">
                <BookOpen className="text-accent h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Reader-Friendly Layout</h3>
              <p className="text-secondary">Optimized typography and spacing creates a comfortable reading experience that keeps readers engaged.</p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Featured Articles Section */}
      <section className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-primary">Featured Articles</h2>
            <p className="mt-3 text-xl text-secondary">See how your content will look on Pencraft</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {isLoading ? (
              Array(3).fill(0).map((_, i) => (
                <div key={i} className="bg-white rounded-lg shadow-sm border border-neutral-100 flex flex-col">
                  <div className="h-48 bg-neutral-100 animate-pulse" />
                  <div className="p-6 space-y-3">
                    <div className="h-6 bg-neutral-100 rounded animate-pulse w-1/3" />
                    <div className="h-8 bg-neutral-100 rounded animate-pulse" />
                    <div className="h-20 bg-neutral-100 rounded animate-pulse" />
                    <div className="h-8 bg-neutral-100 rounded animate-pulse w-1/2" />
                  </div>
                </div>
              ))
            ) : featuredArticles.length > 0 ? (
              featuredArticles.map(article => (
                <ArticleCard key={article.id} article={article} />
              ))
            ) : (
              <div className="col-span-3 p-8 text-center">
                <p className="text-secondary">No articles found. Create the first one!</p>
                <Link href="/create">
                  <Button className="mt-4 cursor-pointer">Create Article</Button>
                </Link>
              </div>
            )}
          </div>
          
          <div className="mt-12 text-center">
            <Link href="/articles">
              <span className="inline-flex items-center text-accent font-medium hover:text-blue-700 cursor-pointer">
                View all articles
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-1" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M12.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
                </svg>
              </span>
            </Link>
          </div>
        </div>
      </section>
      
      {/* Editor Preview Section */}
      <section className="bg-neutral-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-primary">Powerful Editor, Beautiful Results</h2>
            <p className="mt-3 text-xl text-secondary max-w-3xl mx-auto">Our rich text editor gives you everything you need to create stunning articles.</p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="bg-white rounded-lg shadow-md p-6 border border-neutral-100 order-2 lg:order-1">
              <div className="mb-6 border-b border-neutral-100 pb-4">
                <div className="flex gap-2 mb-4">
                  <button className="p-2 hover:bg-neutral-50 rounded" title="Bold">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="h-5 w-5 text-secondary">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 12h6m0 0h6m-6 0V6m0 6v6" />
                    </svg>
                  </button>
                  <button className="p-2 hover:bg-neutral-50 rounded" title="Italic">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="h-5 w-5 text-secondary">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                    </svg>
                  </button>
                  <button className="p-2 hover:bg-neutral-50 rounded" title="Underline">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="h-5 w-5 text-secondary">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 12h14" />
                    </svg>
                  </button>
                  <span className="border-r border-neutral-100 mx-1"></span>
                  <button className="p-2 hover:bg-neutral-50 rounded" title="Heading">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="h-5 w-5 text-secondary">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z" />
                    </svg>
                  </button>
                  <button className="p-2 hover:bg-neutral-50 rounded" title="Quote">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="h-5 w-5 text-secondary">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                    </svg>
                  </button>
                  <button className="p-2 hover:bg-neutral-50 rounded" title="Code">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="h-5 w-5 text-secondary">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                    </svg>
                  </button>
                  <span className="border-r border-neutral-100 mx-1"></span>
                  <button className="p-2 hover:bg-neutral-50 rounded" title="Link">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="h-5 w-5 text-secondary">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                    </svg>
                  </button>
                  <button className="p-2 hover:bg-neutral-50 rounded" title="Image">
                    <Image className="h-5 w-5 text-secondary" />
                  </button>
                </div>
              </div>
              
              {/* Editor content preview */}
              <div className="article-content">
                <h1 className="text-2xl font-bold mb-4">The Art of Content Creation</h1>
                <p className="mb-4">In today's digital world, content is king. But creating engaging content consistently can be challenging for even the most seasoned writers.</p>
                <p className="mb-4">Here are three principles that can help improve your content creation process:</p>
                <ol className="list-decimal pl-5 mb-4 space-y-2">
                  <li><strong>Know your audience</strong> - Understanding who you're writing for is essential.</li>
                  <li><strong>Create valuable content</strong> - Focus on solving problems or providing insights.</li>
                  <li><strong>Be consistent</strong> - Establish a regular publishing schedule.</li>
                </ol>
                <div className="my-6 bg-neutral-50 p-4 border-l-4 border-accent italic">
                  "The best content doesn't feel like marketing—it feels like valuable information shared by a trusted friend."
                </div>
                <p>Remember that great content takes time to create. Don't rush the process, and always prioritize quality over quantity.</p>
              </div>
            </div>
            
            <div className="order-1 lg:order-2 space-y-6">
              <div className="bg-white rounded-lg shadow-sm p-6 border border-neutral-100">
                <div className="w-12 h-12 bg-accent bg-opacity-10 rounded-lg flex items-center justify-center mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-accent h-6 w-6">
                    <path d="M21 11l-8-8-8 8v2h16v-2zm-4 4v5a1 1 0 01-1 1h-6a1 1 0 01-1-1v-5" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-2">Intuitive Formatting</h3>
                <p className="text-secondary">Format text, create lists, add quotes, and more with our easy-to-use toolbar. No coding knowledge required.</p>
              </div>
              
              <div className="bg-white rounded-lg shadow-sm p-6 border border-neutral-100">
                <div className="w-12 h-12 bg-accent bg-opacity-10 rounded-lg flex items-center justify-center mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-accent h-6 w-6">
                    <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
                    <circle cx="8.5" cy="8.5" r="1.5" />
                    <polyline points="21 15 16 10 5 21" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-2">Drag & Drop Images</h3>
                <p className="text-secondary">Add visual impact to your articles by simply dragging and dropping images directly into your content.</p>
              </div>
              
              <div className="bg-white rounded-lg shadow-sm p-6 border border-neutral-100">
                <div className="w-12 h-12 bg-accent bg-opacity-10 rounded-lg flex items-center justify-center mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-accent h-6 w-6">
                    <circle cx="12" cy="12" r="10" />
                    <polyline points="12 6 12 12 16 14" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-2">Auto-Save & Revisions</h3>
                <p className="text-secondary">Never lose your work. Pencraft automatically saves your drafts and keeps a history of revisions.</p>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="bg-accent py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white sm:text-4xl mb-6">Ready to Start Your Writing Journey?</h2>
          <p className="text-xl text-white opacity-90 max-w-3xl mx-auto mb-8">Join Pencraft today and transform your writing experience with our powerful yet simple blogging platform.</p>
          <div className="max-w-md mx-auto">
            <Card className="shadow-lg">
              <CardContent className="pt-6 pb-6">
                <h3 className="text-xl font-semibold mb-4 text-primary">Join Our Early Access List</h3>
                
                {!submissionSuccess ? (
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                      <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Your Name</FormLabel>
                            <FormControl>
                              <Input placeholder="John Doe" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email Address</FormLabel>
                            <FormControl>
                              <Input placeholder="john@example.com" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="useCase"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>What will you use Pencraft for?</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select an option" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="personal">Personal Blog</SelectItem>
                                <SelectItem value="business">Business Blog</SelectItem>
                                <SelectItem value="publication">Online Publication</SelectItem>
                                <SelectItem value="other">Other</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <Button 
                        type="submit" 
                        className="w-full bg-accent hover:bg-blue-600 text-white"
                        disabled={submitting}
                      >
                        {submitting ? 'Processing...' : 'Join the Waitlist'}
                      </Button>
                      
                      <p className="text-xs text-neutral-200 text-center">
                        By signing up, you agree to our Terms of Service and Privacy Policy.
                      </p>
                    </form>
                  </Form>
                ) : (
                  <div className="text-center p-4">
                    <div className="w-16 h-16 bg-success rounded-full flex items-center justify-center mx-auto mb-4">
                      <CheckIcon className="text-white h-8 w-8" />
                    </div>
                    <h3 className="text-xl font-semibold mb-2">You're on the List!</h3>
                    <p className="text-secondary">Thank you for joining our waitlist. We'll notify you when we launch.</p>
                    <p className="mt-4 text-sm text-accent">We sent a confirmation to {form.getValues().email}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;

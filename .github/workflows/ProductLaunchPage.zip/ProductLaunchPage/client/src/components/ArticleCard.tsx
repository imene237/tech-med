import { Link, useLocation } from 'wouter';
import { formatDate, safeNavigate } from '@/lib/utils';
import CategoryBadge from './CategoryBadge';
import { useQuery } from '@tanstack/react-query';
import { Skeleton } from '@/components/ui/skeleton';
import type { Article, Category, User } from '@shared/schema';

interface ArticleCardProps {
  article: Article;
}

const ArticleCard = ({ article }: ArticleCardProps) => {
  const [, navigate] = useLocation();
  
  // Fetch category data
  const { data: category, isLoading: isCategoryLoading } = useQuery<Category>({
    queryKey: [`/api/categories/${article.categoryId}`],
  });

  // Fetch author data
  const { data: author, isLoading: isAuthorLoading } = useQuery<User>({
    queryKey: [`/api/users/${article.authorId}`],
  });
  
  // Handle navigation to article
  const handleArticleClick = (e: React.MouseEvent) => {
    e.preventDefault();
    safeNavigate(navigate, `/articles/${article.slug}`);
  };

  return (
    <article className="bg-gray-800 rounded-lg overflow-hidden shadow-md border border-gray-700 flex flex-col h-full transition-transform hover:scale-[1.01] hover:shadow-lg">
      {article.coverImage ? (
        <div className="h-48 overflow-hidden">
          <img 
            src={article.coverImage} 
            alt={article.title} 
            className="h-full w-full object-cover transition-transform duration-300 hover:scale-105"
          />
        </div>
      ) : (
        <div className="h-48 bg-gray-700 flex items-center justify-center">
          <span className="text-gray-400 text-sm">No cover image</span>
        </div>
      )}
      
      <div className="p-6 flex-grow flex flex-col">
        <div className="flex items-center gap-2 mb-2">
          {isCategoryLoading ? (
            <Skeleton className="h-6 w-20" />
          ) : category ? (
            <CategoryBadge name={category.name} slug={category.slug} />
          ) : null}
          
          <span className="text-sm text-gray-400">
            {formatDate(article.createdAt)}
          </span>
        </div>
        
        <h3 className="text-xl font-semibold mb-2">
          <a 
            href={`/articles/${article.slug}`} 
            onClick={handleArticleClick}
            className="text-white hover:text-purple-400 transition-colors cursor-pointer"
          >
            {article.title}
          </a>
        </h3>
        
        <p className="text-gray-300 mb-4 flex-grow">
          {article.excerpt}
        </p>
        
        <div className="flex items-center mt-auto pt-2 border-t border-gray-700">
          {isAuthorLoading ? (
            <div className="flex items-center">
              <Skeleton className="h-8 w-8 rounded-full mr-2" />
              <Skeleton className="h-4 w-24" />
            </div>
          ) : author ? (
            <>
              <div className="w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center text-white mr-2">
                {author.username.charAt(0).toUpperCase()}
              </div>
              <span className="text-sm font-medium text-gray-300">{author.username}</span>
            </>
          ) : null}
        </div>
      </div>
    </article>
  );
};

export default ArticleCard;

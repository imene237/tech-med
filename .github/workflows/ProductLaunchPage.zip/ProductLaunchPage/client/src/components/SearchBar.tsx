import { useState, useRef, useEffect } from 'react';
import { useLocation } from 'wouter';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { cn } from '@/lib/utils';
import type { Article } from '@shared/schema';

interface SearchBarProps {
  isMobile?: boolean;
}

const SearchBar = ({ isMobile = false }: SearchBarProps) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);
  const [, navigate] = useLocation();

  // Query for all articles to search through
  const { data: articles } = useQuery<Article[]>({
    queryKey: ['/api/articles'],
    enabled: isOpen && searchTerm.length > 0,
    staleTime: 60000, // 1 minute
  });

  const filteredArticles = articles?.filter(article => 
    article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    article.excerpt.toLowerCase().includes(searchTerm.toLowerCase())
  ) || [];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
    if (e.target.value.length > 0) {
      setIsOpen(true);
    } else {
      setIsOpen(false);
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      navigate(`/articles?search=${encodeURIComponent(searchTerm.trim())}`);
      setIsOpen(false);
    }
  };

  const handleArticleClick = (slug: string) => {
    navigate(`/articles/${slug}`);
    setSearchTerm('');
    setIsOpen(false);
  };

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <div className={cn("relative", isMobile ? "w-full" : "w-48")} ref={searchRef}>
      <form onSubmit={handleSearchSubmit}>
        <div className="relative">
          <Input
            type="text"
            placeholder="Search articles..."
            value={searchTerm}
            onChange={handleInputChange}
            className={cn(
              "pl-3 pr-10 py-2 border border-neutral-100 rounded-md focus:outline-none focus:ring-1 focus:ring-accent focus:border-accent text-sm",
              isMobile && "w-full"
            )}
          />
          <Button 
            type="submit"
            variant="ghost" 
            size="icon" 
            className="absolute inset-y-0 right-0 flex items-center pr-3 text-neutral-200"
          >
            <Search className="h-4 w-4" />
          </Button>
        </div>
      </form>

      {isOpen && searchTerm.length > 0 && (
        <div className="absolute z-10 mt-1 w-full bg-white shadow-lg rounded-md border border-neutral-100 overflow-hidden max-h-60 overflow-y-auto">
          {filteredArticles.length > 0 ? (
            <ul className="py-1">
              {filteredArticles.map(article => (
                <li key={article.id}>
                  <button
                    onClick={() => handleArticleClick(article.slug)}
                    className="block w-full text-left px-4 py-2 text-sm hover:bg-neutral-50"
                  >
                    {article.title}
                  </button>
                </li>
              ))}
            </ul>
          ) : (
            <div className="px-4 py-3 text-sm text-neutral-200">
              No articles found.
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default SearchBar;

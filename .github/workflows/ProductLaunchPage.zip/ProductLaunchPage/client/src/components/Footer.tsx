import { Link } from "wouter";
import { Facebook, Twitter, Instagram, Github, Cpu, Zap } from "lucide-react";

const Footer = () => {
  // Social media component
  const SocialIcon = ({ icon, label }: { icon: React.ReactNode, label: string }) => (
    <span className="text-neutral-200 hover:text-white cursor-pointer" role="link" aria-label={label}>
      {icon}
    </span>
  );

  // Footer link component
  const FooterLink = ({ href, children }: { href: string, children: React.ReactNode }) => (
    <span className="text-neutral-200 hover:text-white cursor-pointer" role="link">
      {children}
    </span>
  );

  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <h2 className="text-2xl font-bold mb-4 flex items-center">
              <Cpu className="mr-2 h-6 w-6 text-purple-400" />
              <span className="bg-gradient-to-r from-purple-400 to-indigo-300 bg-clip-text text-transparent">
                Electronics in Med School
              </span>
            </h2>
            <p className="text-gray-300 mb-4 max-w-md">
              Exploring the intersection of electronics and medical education - your resource for understanding the technology that powers modern healthcare.
            </p>
            <div className="flex space-x-4">
              <SocialIcon icon={<Twitter className="h-5 w-5" />} label="Twitter" />
              <SocialIcon icon={<Facebook className="h-5 w-5" />} label="Facebook" />
              <SocialIcon icon={<Instagram className="h-5 w-5" />} label="Instagram" />
              <SocialIcon icon={<Github className="h-5 w-5" />} label="GitHub" />
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Platform</h3>
            <ul className="space-y-2">
              <li><FooterLink href="#">Features</FooterLink></li>
              <li><FooterLink href="#">Pricing</FooterLink></li>
              <li><FooterLink href="#">Roadmap</FooterLink></li>
              <li><FooterLink href="#">Releases</FooterLink></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Company</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/about">
                  <span className="text-neutral-200 hover:text-white cursor-pointer">About</span>
                </Link>
              </li>
              <li>
                <Link href="/articles">
                  <span className="text-neutral-200 hover:text-white cursor-pointer">Blog</span>
                </Link>
              </li>
              <li><FooterLink href="#">Contact</FooterLink></li>
              <li><FooterLink href="#">Careers</FooterLink></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-300 text-sm">&copy; {new Date().getFullYear()} Electronics in Med School. All rights reserved.</p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <span className="text-neutral-200 hover:text-white text-sm cursor-pointer" role="link">Privacy Policy</span>
            <span className="text-neutral-200 hover:text-white text-sm cursor-pointer" role="link">Terms of Service</span>
            <span className="text-neutral-200 hover:text-white text-sm cursor-pointer" role="link">Cookie Policy</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

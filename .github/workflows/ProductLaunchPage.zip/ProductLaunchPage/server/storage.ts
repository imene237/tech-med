import { 
  users, type User, type InsertUser,
  categories, type Category, type InsertCategory,
  articles, type Article, type InsertArticle,
  waitlist, type Waitlist, type InsertWaitlist
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Category methods
  getCategories(): Promise<Category[]>;
  getCategory(id: number): Promise<Category | undefined>;
  getCategoryBySlug(slug: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;

  // Article methods
  getArticles(filters?: {
    published?: boolean;
    categoryId?: number;
    authorId?: number;
  }): Promise<Article[]>;
  getArticle(id: number): Promise<Article | undefined>;
  getArticleBySlug(slug: string): Promise<Article | undefined>;
  createArticle(article: InsertArticle): Promise<Article>;
  updateArticle(id: number, article: Partial<InsertArticle>): Promise<Article | undefined>;
  deleteArticle(id: number): Promise<boolean>;

  // Waitlist methods
  addToWaitlist(entry: InsertWaitlist): Promise<Waitlist>;
  getWaitlistEntries(): Promise<Waitlist[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private categories: Map<number, Category>;
  private articles: Map<number, Article>;
  private waitlistEntries: Map<number, Waitlist>;

  private userCounter: number;
  private categoryCounter: number;
  private articleCounter: number;
  private waitlistCounter: number;

  constructor() {
    this.users = new Map();
    this.categories = new Map();
    this.articles = new Map();
    this.waitlistEntries = new Map();

    this.userCounter = 1;
    this.categoryCounter = 1;
    this.articleCounter = 1;
    this.waitlistCounter = 1;

    // Initialize with default data and load saved articles
    this.initializeDefaultData();
    this.loadArticlesFromFile();
  }

  private initializeDefaultData() {
    // Create default admin user
    const admin: User = {
      id: this.userCounter++,
      username: 'admin',
      password: 'admin123', // In a real app, this would be hashed
    };
    this.users.set(admin.id, admin);

    // Create default categories for medical electronics
    const categories: InsertCategory[] = [
      { name: 'Surgical Electronics', slug: 'surgical-electronics' },
      { name: 'Medical Imaging', slug: 'medical-imaging' },
      { name: 'Patient Monitoring', slug: 'patient-monitoring' },
      { name: 'Wearable Devices', slug: 'wearable-devices' },
      { name: 'Medical Robotics', slug: 'medical-robotics' }
    ];

    categories.forEach(category => this.createCategory(category));

    // Create initial article
    const initialArticle: InsertArticle = {
      title: "Electronics are everywhere in your daily life!",
      slug: "electronics-everywhere-daily-life",
      content: `<h2>Electronics are everywhere in your daily life!</h2><p>From the moment you wake up to the moment you go to sleep, electronics play a crucial role in modern medicine and healthcare. Medical professionals rely on sophisticated electronic devices for diagnosis, treatment, and monitoring of patients.</p><p>In medical schools, students are increasingly being trained in the use of electronic equipment and understanding the principles behind these technologies. This knowledge is essential for future healthcare providers to deliver effective care in an increasingly digitized medical environment.</p><p>Stay tuned to our blog for more insights into the fascinating world of medical electronics!</p>`,
      excerpt: "From the moment you wake up to the moment you go to sleep, electronics play a crucial role in modern medicine and healthcare.",
      categoryId: 1, // Surgical Electronics category
      authorId: 1, // Admin user
      published: true,
      coverImage: null
    };

    this.createArticle(initialArticle);
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCounter++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Category methods
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }

  async getCategory(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }

  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    return Array.from(this.categories.values()).find(
      (category) => category.slug === slug,
    );
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const id = this.categoryCounter++;
    const category: Category = { ...insertCategory, id };
    this.categories.set(id, category);
    console.log(`Category created: ${category.name} with ID ${id}`);
    return category;
  }

  // Article methods
  async getArticles(filters?: {
    published?: boolean;
    categoryId?: number;
    authorId?: number;
  }): Promise<Article[]> {
    let articles = Array.from(this.articles.values());

    if (filters) {
      if (filters.published !== undefined) {
        articles = articles.filter(article => article.published === filters.published);
      }

      if (filters.categoryId !== undefined) {
        articles = articles.filter(article => article.categoryId === filters.categoryId);
      }

      if (filters.authorId !== undefined) {
        articles = articles.filter(article => article.authorId === filters.authorId);
      }
    }

    // Sort by most recent first
    return articles.sort((a, b) => {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
  }

  async getArticle(id: number): Promise<Article | undefined> {
    return this.articles.get(id);
  }

  async getArticleBySlug(slug: string): Promise<Article | undefined> {
    return Array.from(this.articles.values()).find(
      (article) => article.slug === slug,
    );
  }

  async createArticle(insertArticle: InsertArticle): Promise<Article> {
    const id = this.articleCounter++;
    const now = new Date();
    const article: Article = {
      ...insertArticle,
      id,
      createdAt: now,
      updatedAt: now,
    };
    this.articles.set(id, article);
    await this.saveArticlesToFile();
    return article;
  }

  private async saveArticlesToFile() {
    const fs = await import('fs/promises');
    const articles = Array.from(this.articles.values());
    await fs.writeFile('articles.json', JSON.stringify(articles, null, 2));
  }

  private async loadArticlesFromFile() {
    const fs = await import('fs/promises');
    try {
      const data = await fs.readFile('articles.json', 'utf-8');
      const articles = JSON.parse(data);
      articles.forEach(article => {
        this.articles.set(article.id, article);
        if (article.id >= this.articleCounter) {
          this.articleCounter = article.id + 1;
        }
      });
    } catch (error) {
      // File doesn't exist yet, which is fine for new installations
    }
  }

  async updateArticle(id: number, updates: Partial<InsertArticle>): Promise<Article | undefined> {
    const article = this.articles.get(id);
    if (!article) return undefined;

    const updatedArticle: Article = {
      ...article,
      ...updates,
      updatedAt: new Date(),
    };

    this.articles.set(id, updatedArticle);
    await this.saveArticlesToFile();
    return updatedArticle;
  }

  async deleteArticle(id: number): Promise<boolean> {
    const result = this.articles.delete(id);
    if (result) {
      await this.saveArticlesToFile();
    }
    return result;
  }

  // Waitlist methods
  async addToWaitlist(insertWaitlist: InsertWaitlist): Promise<Waitlist> {
    const id = this.waitlistCounter++;
    const entry: Waitlist = {
      ...insertWaitlist,
      id,
      createdAt: new Date(),
    };
    this.waitlistEntries.set(id, entry);
    return entry;
  }

  async getWaitlistEntries(): Promise<Waitlist[]> {
    return Array.from(this.waitlistEntries.values());
  }
}

export const storage = new MemStorage();
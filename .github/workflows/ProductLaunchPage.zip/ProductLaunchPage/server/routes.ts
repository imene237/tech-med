import express, { type Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertArticleSchema, 
  insertCategorySchema, 
  insertUserSchema,
  insertWaitlistSchema 
} from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import multer from "multer";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Create uploads directory if it doesn't exist
const uploadsDir = path.join(__dirname, "..", "uploads");
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Configure multer for file uploads
const storage_config = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadsDir);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const ext = path.extname(file.originalname);
    cb(null, `${uniqueSuffix}${ext}`);
  }
});

const upload = multer({ 
  storage: storage_config,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB
  },
  fileFilter: (req, file, cb) => {
    // Accept only images
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // API Routes
  const apiRouter = express.Router();
  
  // Error handler middleware for API routes
  const handleApiError = (err: any, res: Response) => {
    console.error(err);
    
    if (err instanceof ZodError) {
      const validationError = fromZodError(err);
      return res.status(400).json({ 
        message: "Validation error", 
        errors: validationError.details
      });
    }
    
    return res.status(500).json({ message: err.message || "Internal server error" });
  };
  
  // Helper to generate slug from a string
  const generateSlug = (text: string): string => {
    return text
      .toString()
      .toLowerCase()
      .replace(/\s+/g, '-')        // Replace spaces with -
      .replace(/[^\w\-]+/g, '')    // Remove all non-word chars
      .replace(/\-\-+/g, '-')      // Replace multiple - with single -
      .replace(/^-+/, '')          // Trim - from start of text
      .replace(/-+$/, '');         // Trim - from end of text
  };
  
  // WAITLIST ROUTES
  // Add to waitlist
  apiRouter.post('/waitlist', async (req: Request, res: Response) => {
    try {
      const waitlistEntry = insertWaitlistSchema.parse(req.body);
      const result = await storage.addToWaitlist(waitlistEntry);
      res.status(201).json(result);
    } catch (err: any) {
      handleApiError(err, res);
    }
  });

  // CATEGORIES ROUTES
  // Get all categories
  apiRouter.get('/categories', async (req: Request, res: Response) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (err: any) {
      handleApiError(err, res);
    }
  });
  
  // Get category by ID
  apiRouter.get('/categories/:id(\\d+)', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id, 10);
      const category = await storage.getCategory(id);
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      res.json(category);
    } catch (err: any) {
      handleApiError(err, res);
    }
  });
  
  // Get category by slug
  apiRouter.get('/categories/:slug([a-z0-9-]+)', async (req: Request, res: Response) => {
    try {
      const category = await storage.getCategoryBySlug(req.params.slug);
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      res.json(category);
    } catch (err: any) {
      handleApiError(err, res);
    }
  });
  
  // Create category
  apiRouter.post('/categories', async (req: Request, res: Response) => {
    try {
      const categoryData = insertCategorySchema.parse(req.body);
      
      // Generate slug if not provided
      if (!categoryData.slug) {
        categoryData.slug = generateSlug(categoryData.name);
      }
      
      const category = await storage.createCategory(categoryData);
      res.status(201).json(category);
    } catch (err: any) {
      handleApiError(err, res);
    }
  });
  
  // ARTICLES ROUTES
  // Get all articles
  apiRouter.get('/articles', async (req: Request, res: Response) => {
    try {
      const filters: { published?: boolean; categoryId?: number; authorId?: number } = {};
      
      if (req.query.published !== undefined) {
        filters.published = req.query.published === 'true';
      }
      
      if (req.query.categoryId) {
        filters.categoryId = Number(req.query.categoryId);
      }
      
      if (req.query.authorId) {
        filters.authorId = Number(req.query.authorId);
      }
      
      const articles = await storage.getArticles(filters);
      res.json(articles);
    } catch (err: any) {
      handleApiError(err, res);
    }
  });
  
  // Get article by ID
  apiRouter.get('/articles/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id, 10);
      const article = await storage.getArticle(id);
      
      if (!article) {
        return res.status(404).json({ message: "Article not found" });
      }
      
      res.json(article);
    } catch (err: any) {
      handleApiError(err, res);
    }
  });
  
  // Get article by slug
  apiRouter.get('/articles/slug/:slug', async (req: Request, res: Response) => {
    try {
      const article = await storage.getArticleBySlug(req.params.slug);
      
      if (!article) {
        return res.status(404).json({ message: "Article not found" });
      }
      
      res.json(article);
    } catch (err: any) {
      handleApiError(err, res);
    }
  });
  
  // Create article
  apiRouter.post('/articles', async (req: Request, res: Response) => {
    try {
      let articleData = insertArticleSchema.parse(req.body);
      
      // Generate slug from title if not provided
      if (!articleData.slug) {
        articleData.slug = generateSlug(articleData.title);
      }
      
      const article = await storage.createArticle(articleData);
      res.status(201).json(article);
    } catch (err: any) {
      handleApiError(err, res);
    }
  });
  
  // Update article
  apiRouter.put('/articles/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id, 10);
      const updates = req.body;
      
      // Generate new slug if title is updated
      if (updates.title && !updates.slug) {
        updates.slug = generateSlug(updates.title);
      }
      
      const article = await storage.updateArticle(id, updates);
      
      if (!article) {
        return res.status(404).json({ message: "Article not found" });
      }
      
      res.json(article);
    } catch (err: any) {
      handleApiError(err, res);
    }
  });
  
  // Delete article
  apiRouter.delete('/articles/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id, 10);
      const success = await storage.deleteArticle(id);
      
      if (!success) {
        return res.status(404).json({ message: "Article not found" });
      }
      
      res.status(204).end();
    } catch (err: any) {
      handleApiError(err, res);
    }
  });
  
  // File upload for article images
  apiRouter.post('/upload', upload.single('image'), (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      
      const filename = req.file.filename;
      const filePath = `/uploads/${filename}`;
      
      res.json({
        filename,
        path: filePath,
        url: filePath
      });
    } catch (err: any) {
      handleApiError(err, res);
    }
  });
  
  // Serve uploaded files
  app.use('/uploads', express.static(uploadsDir));
  
  // Register the API routes
  app.use('/api', apiRouter);

  const httpServer = createServer(app);

  return httpServer;
}
